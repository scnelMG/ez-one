(()=>{const d="ezone-extension-panel-host",p="EZONE_PANEL_RESIZE",c="ezonePanelWidth";let s=null;m();function m(){if(document.getElementById(d)){h();return}E()}function E(){const e=document.createElement("div");e.id=d;const t=e.attachShadow({mode:"closed"}),o=document.createElement("style"),n=document.createElement("iframe"),i=document.createElement("button"),r=document.createElement("div");o.textContent=`
            :host {
                all: initial;
                position: fixed;
                top: 12px;
                right: 12px;
                z-index: 2147483647;
            }

            .panel {
                position: fixed;
                top: 12px;
                right: 12px;
                width: min(360px, calc(100vw - 24px));
                height: min(420px, calc(100vh - 24px));
                min-height: min(220px, calc(100vh - 24px));
                max-height: calc(100vh - 24px);
                overflow: hidden;
                border: 1px solid rgba(17, 24, 39, 0.14);
                border-radius: 14px;
                background: #f7f8fb;
                box-shadow: 0 18px 46px rgba(17, 24, 39, 0.28);
                transition: height 160ms ease;
            }

            .panel.is-resizing iframe {
                pointer-events: none;
            }

            .resize-handle {
                position: absolute;
                top: 14px;
                bottom: 14px;
                left: 0;
                width: 10px;
                cursor: ew-resize;
                z-index: 2147483647;
            }

            .resize-handle::after {
                content: "";
                position: absolute;
                top: 50%;
                left: 3px;
                width: 3px;
                height: 44px;
                border-radius: 999px;
                background: rgba(91, 69, 240, 0.18);
                transform: translateY(-50%);
                transition: background 120ms ease, height 120ms ease;
            }

            .resize-handle:hover::after,
            .panel.is-resizing .resize-handle::after {
                height: 58px;
                background: rgba(91, 69, 240, 0.42);
            }

            iframe {
                display: block;
                width: 100%;
                height: 100%;
                border: 0;
                background: #f7f8fb;
            }

            button {
                position: fixed;
                top: 26px;
                right: 26px;
                display: grid;
                width: 24px;
                height: 24px;
                place-items: center;
                border: 0;
                border-radius: 999px;
                background: transparent;
                color: #4b5563;
                cursor: pointer;
                z-index: 2147483647;
            }

            button::before,
            button::after {
                content: "";
                position: absolute;
                top: 50%;
                left: 50%;
                width: 14px;
                height: 2px;
                border-radius: 999px;
                background: currentColor;
            }

            button::before {
                transform: translate(-50%, -50%) rotate(45deg);
            }

            button::after {
                transform: translate(-50%, -50%) rotate(-45deg);
            }

            button:hover {
                background: rgba(17, 24, 39, 0.05);
                color: #111827;
            }
        `,n.src=chrome.runtime.getURL("popup.html?embedded=1"),n.title="EZ-ONE",i.type="button",i.setAttribute("aria-label","EZ-ONE close"),i.title="Close",i.addEventListener("click",h),r.className="resize-handle",r.setAttribute("role","separator"),r.setAttribute("aria-orientation","vertical"),r.setAttribute("aria-label","Resize EZ-ONE panel");const a=document.createElement("div");a.className="panel",a.append(r,n),t.append(o,a,i),document.documentElement.append(e),b(a),s=l=>{g(l,a,n)},window.addEventListener("message",s),r.addEventListener("pointerdown",l=>{P(l,a)})}function g(e,t,o){var n;e.source!==o.contentWindow||((n=e.data)==null?void 0:n.type)!==p||L(t,Number(e.data.height))}async function b(e){const t=await x();u(e,t??360)}async function x(){try{const e=await chrome.storage.local.get([c]),t=Number(e==null?void 0:e[c]);return Number.isFinite(t)?t:null}catch{return null}}function P(e,t){e.preventDefault(),t.classList.add("is-resizing"),document.documentElement.style.cursor="ew-resize",document.documentElement.style.userSelect="none";const o=i=>{const r=window.innerWidth-12-i.clientX;u(t,r)},n=()=>{t.classList.remove("is-resizing"),document.documentElement.style.cursor="",document.documentElement.style.userSelect="",document.removeEventListener("pointermove",o),document.removeEventListener("pointerup",n),N(t)};_(e),document.addEventListener("pointermove",o),document.addEventListener("pointerup",n,{once:!0})}function _(e){try{e.currentTarget.setPointerCapture(e.pointerId)}catch{}}function u(e,t){const o=Math.max(320,window.innerWidth-12-12),n=Math.min(Math.max(t,320),520,o);e.style.width=`${n}px`}function L(e,t){if(!Number.isFinite(t))return;const o=Math.max(220,window.innerHeight-24),n=Math.min(Math.max(t,420),o),i=Math.round(n),r=Math.round(e.getBoundingClientRect().height);Math.abs(r-i)<2||(e.style.height=`${i}px`)}function N(e){const t=Math.round(e.getBoundingClientRect().width);chrome.storage.local.set({[c]:t}).catch(()=>{})}function h(){var e;s&&(window.removeEventListener("message",s),s=null),(e=document.getElementById(d))==null||e.remove()}})();
